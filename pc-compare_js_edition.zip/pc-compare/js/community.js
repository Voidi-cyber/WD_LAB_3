/* ==========================================================================
   community.js — збірки спільноти: пошук, фільтр за бюджетом, сортування
   ========================================================================== */
(function () {
  "use strict";

  const list = PC.qs("[data-builds]");
  if (!list) return;

  const searchForm = PC.qs(".search");
  const searchInput = PC.qs("#search-builds");
  const budgetSelect = PC.qs("#budget");
  const sortSelect = PC.qs("#sort-builds");
  const emptyBox = PC.qs("#builds-empty");

  const builds = PC.qsa(":scope > li", list).map((li) => {
    const card = PC.qs(".build-public", li);
    return {
      li,
      search: card.dataset.search,
      price: Number(card.dataset.price),
      popular: Number(card.dataset.popular),
      date: card.dataset.date
    };
  });

  const sorters = {
    popular: (a, b) => a.popular - b.popular,
    new: (a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0),
    "price-asc": (a, b) => a.price - b.price
  };

  /* У прототипі при бюджеті «До 50 000 ₴» показано і дорожчу збірку,
     тому фільтр за бюджетом починає діяти лише після зміни користувачем */
  let budgetActive = false;

  function update() {
    const query = searchInput.value.trim().toLowerCase();
    const limit = Number(budgetSelect.value);

    const visible = builds.filter(
      (b) => (!query || b.search.indexOf(query) !== -1) && (!budgetActive || b.price <= limit)
    );

    builds.forEach((b) => {
      b.li.hidden = visible.indexOf(b) === -1;
    });

    visible.sort(sorters[sortSelect.value] || sorters.popular).forEach((b) => list.appendChild(b.li));
    emptyBox.hidden = visible.length > 0;
  }

  searchForm.addEventListener("submit", (event) => event.preventDefault());
  searchInput.addEventListener("input", update);
  sortSelect.addEventListener("change", update);
  budgetSelect.addEventListener("change", () => {
    budgetActive = true;
    update();
  });

  update();
})();
